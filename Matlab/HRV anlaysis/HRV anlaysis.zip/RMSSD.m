% RMSSD
% ouput is the RMSSD, which is the sqrt(MSE) of the 5 minute epochs of the NN
% intervales. 

function RMSSD(pat,saving,win,overlap)
    for o=1:length(overlap)
      for j=1:length(win)
        for k=1:length(pat)
            Neonate=pat(k);


        %checking if file exist
            cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\saves\windowed_ECG_chunks\Ralphs\')
            folder='C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\saves\windowed_ECG_chunks\HRV analysis\Ralphs\';

            
%%%%%%%%%%%%%AS            
            if exist(fullfile(cd, ['RRdistanceAS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']), 'file') == 2 % ==> 0 or 2
              load(fullfile(cd,['RRdistanceAS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']));
                  for i=1:length(RRdistanceAS)
                         RRdistanceAS{1,i}(any(isnan( RRdistanceAS{1,i})))=[]; %removing nans
                      if RRdistanceAS{1,i}
                          %remove outlier
%                           all_idx = 1:length(RRdistanceAS{1,i});
%                           outlier_idx = abs(RRdistanceAS{1,i} - median(RRdistanceAS{1,i})) > 5*std(RRdistanceAS{1,i}); %| abs(y - median(y)) > 3*std(y) % Find outlier idx
%                           RRdistanceAS{1,i}(outlier_idx) = interp1(all_idx(~outlier_idx), RRdistanceAS{1,i}(~outlier_idx), all_idx(outlier_idx)); % Linearly interpolate over outlier idx for x
                          RRdistanceAS{1,i}(2,:)=circshift(RRdistanceAS{1,i}',[1 0]);   %shifting the array to gain a Y and a Y+1(estimated) with wich we can determine the MSE
                          [PSNR,MSEAS{Neonate,i},MAXERR,L2RAT] = measerr(RRdistanceAS{1,i}(1),RRdistanceAS{1,i}(2)); %Calculating MSE
                          RMSSD_AS=cellfun(@sqrt,MSEAS, 'Un', false); %sqare root over the MSE of the adjacent NN intervals creates the RMSSD
                      end
                  end
            end
            
%%%%%%%%%%%%QS            
            if exist(fullfile(cd, ['RRdistanceQS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']), 'file') == 2 % ==> 0 or 2
              load(fullfile(cd,['RRdistanceQS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']));
            
                   for i=1:length(RRdistanceQS)
                         RRdistanceQS{1,i}(any(isnan( RRdistanceQS{1,i})))=[]; %removing nans
                      if RRdistanceQS{1,i}
%                           all_idx = 1:length(RRdistanceQS{1,i});
%                           outlier_idx = abs(RRdistanceQS{1,i} - median(RRdistanceQS{1,i})) > 5*std(RRdistanceQS{1,i}); %| abs(y - median(y)) > 3*std(y) % Find outlier idx
%                           RRdistanceQS{1,i}(outlier_idx) = interp1(all_idx(~outlier_idx), RRdistanceQS{1,i}(~outlier_idx), all_idx(outlier_idx)); % Linearly interpolate over outlier idx for x
                          RRdistanceQS{1,i}(2,:)=circshift(RRdistanceQS{1,i}',[1 0]);   %shifting the array to gain a Y and a Y+1(estimated) with wich we can determine the MSE
                          [PSNR,MSEQS{Neonate,i},MAXERR,L2RAT] = measerr(RRdistanceQS{1,i}(1),RRdistanceQS{1,i}(2)); %Calculating MSE
                          RMSSD_QS=cellfun(@sqrt,MSEQS, 'Un', false);
                      end
                   end
            end
                   

                   if saving
                    %saving R peaks positions in mat file
                    save([folder 'RMSSD' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat'],'RMSSD_AS','RMSSD_QS');
                   end               

            
        end
      end
    end
end