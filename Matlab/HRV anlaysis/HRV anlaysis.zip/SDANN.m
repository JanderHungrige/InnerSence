% SDANN

function SDANN(pat,saving,win,overlap)
   for o=1:length(overlap)
      for j=1:length(win)
        for k=1:length(pat)
            Neonate=pat(k);


            cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\saves\windowed_ECG_chunks\Ralphs\')
            folder='C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\saves\windowed_ECG_chunks\HRV analysis\Ralphs\';

%%%%%%%%%%%%%AS
            %checking if file exist and loading
            if exist(fullfile(cd, ['RRdistanceAS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']), 'file') == 2 % ==> 0 or 2
              load(fullfile(cd, ['RRdistanceAS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']));
              %removing nan and calculating mean distance    
              for i=1:length(RRdistanceAS)
                      RRdistanceAS{1,i}(any(isnan( RRdistanceAS{1,i})))=[]; %removing nans
                      if RRdistanceAS{1,i} % (1,1) can be nan and then cannot beused as binary 
                        % outlieer removal
%                       all_idx = 1:length(RRdistanceAS{1,i});
%                       outlier_idx = abs(RRdistanceAS{1,i} - median(RRdistanceAS{1,i})) > 5*std(RRdistanceAS{1,i}); %| abs(y - median(y)) > 3*std(y) % Find outlier idx
%                       RRdistanceAS{1,i}(outlier_idx) = interp1(all_idx(~outlier_idx), RRdistanceAS{1,i}(~outlier_idx), all_idx(outlier_idx)); % Linearly interpolate over outlier idx for x
                      meanRRdistanceAS(1,i)=mean(RRdistanceAS{1,i});
                      end
              end
               % calculating STD
              for i=1:length(RRdistanceAS)
                  SDANNAS(Neonate)=nanstd(meanRRdistanceAS);
              end
              if saving
                        %saving R peaks positions in mat file
                        save([folder 'SDANN_AS_' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat'],'SDANNAS');
              end
            end
            
%%%%%%%%%%%%%QS
            %checking if file exist and loading
            if exist(fullfile(cd, ['RRdistanceQS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']), 'file') == 2 % ==> 0 or 2
              load(fullfile(cd, ['RRdistanceQS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']));              
              %removing nan and calculating mean distance    
               for i=1:length(RRdistanceQS)
                  RRdistanceQS{1,i}(any(isnan( RRdistanceQS{1,i})))=[]; %removing nans
                  if RRdistanceQS{1,i}
                      %removing outliers
%                       all_idx = 1:length(RRdistanceQS{1,i});
%                       outlier_idx = abs(RRdistanceQS{1,i} - median(RRdistanceQS{1,i})) > 5*std(RRdistanceQS{1,i}); %| abs(y - median(y)) > 3*std(y) % Find outlier idx
%                       RRdistanceQS{1,i}(outlier_idx) = interp1(all_idx(~outlier_idx), RRdistanceQS{1,i}(~outlier_idx), all_idx(outlier_idx)); % Linearly interpolate over outlier idx for x
                  meanRRdistanceQS(1,i)=mean(RRdistanceQS{1,i});
                  end
               end                 
                %calculate STD
               for i=1:length(RRdistanceQS)
                     SDANNQS(Neonate)=nanstd(meanRRdistanceQS);
               end
                if saving
                        %saving R peaks positions in mat file
                        save([folder 'SDANN_QS_' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat'],'SDANNQS');
                end
            end
  
                               
        end %patient
      end %window
   end %oerlap
end