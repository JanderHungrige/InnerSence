% SDNN
function SDNN(pat,saving,win,overlap)

 for o=1:length(overlap)
    for j=1:length(win)
        for k=1:length(pat)
            Neonate=pat(k);


        %checking if file exist
            cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\saves\windowed_ECG_chunks\Ralphs\')
             
            if exist(fullfile(cd, ['RRdistance' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']), 'file') == 2 % ==> 0 or 2
              load(fullfile(cd, ['RRdistance' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']))
            end
             
%                   


                  %calculate STD
                   for i=1:length(RRdistanceAS)
                         SDNNAS{Neonate,i}=nanstd(RRdistanceAS{1,i});
                   end

                   for i=1:length(RRdistanceQS)
                         SDNNQS{Neonate,i}=nanstd(RRdistanceQS{1,i});
                   end
            
            
                if saving
                    folder='C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\saves\windowed_ECG_chunks\HRV analysis\';
                    %saving R peaks positions in mat file
                    save([folder 'SDNN_' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat'],'SDNNAS','SDNNQS');
                end
            end
        end
    end
  end
