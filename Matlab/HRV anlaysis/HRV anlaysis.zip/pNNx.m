

function pNNx(pat,saving,win,overlap)
    for o=1%:length(overlap)
      for j=1%:length(win)
        for k=1:length(pat)
            Neonate=pat(k);
clearvars NN50_AS NN30_AS NN20_AS NN10_AS NN50_QS NN30_QS NN20_QS NN10_QS laenge

        %checking if file exist
            cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\saves\windowed_ECG_chunks\Ralphs\')
            datei=fullfile(cd, ['RRdistanceAS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']);
            datei2=fullfile(cd, ['RRdistanceQS' num2str(Neonate) ' _ ' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat']);

            if exist(datei, 'file') == 2 % ==> 0 or 2
              load(datei);
           
%%%%%%%%%%%%%%AS
              for l=1:length(RRdistanceAS)
                  laenge(l)=length(RRdistanceAS{1,l});
              end
                  laenge=sum(laenge);
                                      
                  for i=1:length(RRdistanceAS)
                      RRdistanceAS{1,i}(any(isnan( RRdistanceAS{1,i})))=[]; %removing nans
                      if RRdistanceAS{1,i}
                          NN50_AS(1,i)=sum(diff(RRdistanceAS{1,i})>=0.05)/laenge;
                          NN30_AS(1,i)=sum(diff(RRdistanceAS{1,i})>=0.03 <0.05)/laenge;
                          NN20_AS(1,i)=sum(diff(RRdistanceAS{1,i})>=0.02 <0.03)/laenge;
                          NN10_AS(1,i)=sum(diff(RRdistanceAS{1,i})>=0.01 <0.02)/laenge;
                      end
                  end
            end
            
%%%%%%%%%%%%%QS            
             if exist(datei2, 'file') == 2 % ==> 0 or 2
              load(datei2);
                   for i=1:length(RRdistanceQS)
                      RRdistanceQS{1,i}(any(isnan( RRdistanceQS{1,i})))=[]; %removing nans
                      if RRdistanceQS{1,i}
                          NN50_QS(1,i)=(sum(diff(RRdistanceQS{1,i})>=0.05))/laenge;
                          NN30_QS(1,i)=sum(diff(RRdistanceQS{1,i})>=0.03 <0.05)/laenge;
                          NN20_QS(1,i)=sum(diff(RRdistanceQS{1,i})>=0.02 <0.03)/laenge;
                          NN10_QS(1,i)=sum(diff(RRdistanceQS{1,i})>=0.01 <0.02)/laenge;
                      end
                   end
             end
             
                    if saving
                    folder='C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\saves\windowed_ECG_chunks\HRV analysis\Ralphs\';
                    %saving R peaks positions in mat file
                        if exist('NN50_QS')==1
                        save([folder 'pNNx' num2str(pat(1,k)) 'win' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat'],'NN50_AS','NN30_AS','NN20_AS','NN10_AS','NN50_QS', 'NN30_QS','NN20_QS', 'NN10_QS');
                        else
                        save([folder 'pNNx' num2str(pat(1,k)) 'win' num2str(win(1,j)) 's_win_overlap_' num2str(overlap(1,o)) '.mat'],'NN50_AS','NN30_AS','NN20_AS','NN10_AS');
                        end  
                    end
                           

            end
            
        end
      end
    end
