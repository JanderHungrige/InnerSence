%Calling RHV analysis functions
tic
% pat=[3,4,5,6,7,9,10,13,15];
%pat=[3,4,6,7,9,13];
pat=[3,4,5,6,7,9,13,15];



saving=1;
plot=1;
win=[60,120,180,240,300]; %window in seconds
win=[60];
overlap=[0.5,1];
plotting=1;




cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')
%  SDNN(pat,saving,win,overlap);


cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')
%  SDANN(pat,saving,win,overlap);

cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')
%  RMSSD(pat,saving,win,overlap);

cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')
% NNx(pat,saving,win,overlap)

cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')
%  pNNx(pat,saving,win,overlap)

% cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')
% geoNN(pat,saving,win,plot,overlap);
% 
% cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')
% geoAdjacentNN(pat,saving,win,plot,overlap);

cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')

%plotSDNN(plotting, win, pat, overlap)
%  plotSDANN(plotting, win, pat, overlap)
%  plotRMSSD(plotting, win, pat, overlap)
% plotNNx(plotting, win, pat, overlap)
 plotpNNx(plotting, win, pat, overlap)
 
 
cd('C:\Users\310122653\Documents\PhD\InnerSense Data\Matlab\HRV anlaysis')

toc